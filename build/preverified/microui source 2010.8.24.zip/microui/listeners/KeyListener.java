/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package microui.listeners;

/**
 *
 * @author h
 */
public interface KeyListener {
    public void onPress(int key);
}
