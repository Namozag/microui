package microui.lcd;

/**
 *
 * @author Hany ahmed abdallah
 * hanylink@gmail.com
 * hanylink.blogspot.com
 *
 */

public interface Submitable {
    public void submit();
}
