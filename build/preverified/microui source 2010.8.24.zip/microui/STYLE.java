/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package microui;

import javax.microedition.lcdui.Font;

/**
 *
 * @author h
 */
public class STYLE {

    public static int colorBG = 0xFFFFCC;
    public static int colorBGSELECTED = 0xFFFF00;
    public static int colorBGPointed = 0xCCFF66;
    public static int colorText = 0x3366CC;
    public static int colorTextSELECTED = 0x336600;
    public static int colorTextPointed = 0x0000CC;
    public static int colorSelector = 0x003399;
    public static int[] colorLevelColor = {0xCCFFCC, 0xCCFFFF, 0xCCFF99, 0xFFCCCC};

    public static Font font = Font.getDefaultFont();

    public static Font fontTitle = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_MEDIUM);

}
