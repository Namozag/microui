/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package microui.menu.model;

/**
 *
 * @author h
 */
public interface MarkListener {
    void onMark(MicroItem item);
    void onUnmark(MicroItem item);
}
